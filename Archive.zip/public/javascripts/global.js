// Userlist data array for filling in info box
var userListData = [];

// DOM Ready =============================================================
$(document).ready(function() {

    // Populate the user table on initial page load
    //populateTable();

});

// Functions =============================================================

// Fill table with data
function populateTable(data) {

    
};




}




