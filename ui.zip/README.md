# User interface for food truck finder

This is the user interface for the food truck finder